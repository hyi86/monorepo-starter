export { default } from '@monorepo-starter/ui/postcss.config';
