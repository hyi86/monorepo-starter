## Getting Started

### Install Dependencies

```bash
pnpm i
```

### Run Development Server

```bash
pnpm dev
```

## Build & Run Locally

```bash
pnpm build
pnpm start
```
