export default function Page() {
  return <div>Page</div>;
}
