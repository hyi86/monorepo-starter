import InfiniteScroll from './infinite-scroll';

export default function InfiniteScrollPage() {
  return (
    <div>
      <h1>Tanstack Virtual Simple Infinite Scroll</h1>
      <InfiniteScroll />
    </div>
  );
}
