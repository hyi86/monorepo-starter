export default function ExamplePage() {
  return <div>Examples Root Page</div>;
}
