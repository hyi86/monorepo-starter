export default function ExamplePage() {
  return <div>Example Root Page</div>;
}
