export default function AppRouteVirtual12WithParallelRouteListLoading() {
  return <div className="">Loading...</div>;
}
