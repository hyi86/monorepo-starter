import { config } from '@monorepo-starter/eslint-config/next-extend';

/** @type {import("eslint").Linter.Config[]} */
export default config;
