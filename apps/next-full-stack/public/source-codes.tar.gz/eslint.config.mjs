import { config } from '@monorepo-starter/eslint-config/next-extend';

export default config;
