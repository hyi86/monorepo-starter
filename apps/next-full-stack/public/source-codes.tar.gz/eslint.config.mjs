import { config } from '@monorepo-starter/eslint-config/next-fsd';

/** @type {import("eslint").Linter.Config} */
export default config;
