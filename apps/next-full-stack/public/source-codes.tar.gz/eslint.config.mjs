import { config } from '@monorepo-starter/eslint-config/next-fsd';

export default config;
