# `@turbo/typescript-config`

Collection of internal typescript configurations.
