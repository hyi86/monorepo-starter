import { useImmer as useImmerHook } from 'use-immer';

export const useImmer = useImmerHook;
