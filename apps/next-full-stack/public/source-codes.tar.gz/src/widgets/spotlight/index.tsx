export { SpotlightDialog } from './ui/spotlight-dialog';
