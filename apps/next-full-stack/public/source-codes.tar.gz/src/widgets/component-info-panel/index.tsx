export { ComponentInfoPanel } from './ui/component-info-panel';
