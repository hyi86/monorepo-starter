export default function DetailLoading() {
  return <div className="text-amber-700">@detail Loading...</div>;
}
