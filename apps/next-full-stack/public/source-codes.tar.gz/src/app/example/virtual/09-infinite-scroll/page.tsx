import InfiniteScroll from './client';

export default function InfiniteScrollPage() {
  return (
    <div>
      <h1>Tanstack Virtual Simple Infinite Scroll</h1>
      <InfiniteScroll />
    </div>
  );
}
