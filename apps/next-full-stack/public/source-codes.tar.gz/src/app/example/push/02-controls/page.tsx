import { ComplexWebPushButtons } from '~/features/web-push/ui/ComplexWebPushButtons';

export default function WebPushControlsPage() {
  return (
    <div>
      <h1>Complex Buttons</h1>
      <ComplexWebPushButtons />
    </div>
  );
}
