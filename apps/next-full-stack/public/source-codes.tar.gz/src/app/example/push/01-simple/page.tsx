import { SimpleWebPushButton } from '~/features/web-push/ui/simple-web-push-button';

export default function WebPushSimplePage() {
  return (
    <div>
      <h1>기본 사용법</h1>
      <SimpleWebPushButton />
    </div>
  );
}
