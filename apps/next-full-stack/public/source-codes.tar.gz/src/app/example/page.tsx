export default function ExamplePage() {
  return <div className="p-4">Example Root Page</div>;
}
