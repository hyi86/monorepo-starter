export default function AppInterceptingDefault() {
  return null;
}
