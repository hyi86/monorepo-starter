export default function AppRouteParallelDefaultModal() {
  return null;
}
