export default function AppRouteParallelCommentsDefault() {
  return null;
}
