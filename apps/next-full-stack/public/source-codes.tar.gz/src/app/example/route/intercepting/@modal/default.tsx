export default function AppInterceptingModalDefault() {
  return null;
}
