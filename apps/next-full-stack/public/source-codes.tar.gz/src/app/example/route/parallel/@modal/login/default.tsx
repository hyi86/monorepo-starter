export default function AppRouteParallelLoginDefault() {
  return null;
}
