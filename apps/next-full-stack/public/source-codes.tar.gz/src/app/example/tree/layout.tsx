export default function TreeLayout({ children }: LayoutProps<'/example/tree'>) {
  return <div className="p-4">{children}</div>;
}
