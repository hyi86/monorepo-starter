export default function TreeLayout({ children }: LayoutProps<'/example/tree'>) {
  return <div className="not-prose p-4">{children}</div>;
}
