import { Preview } from './preview';

export default function CodeBlockPreviewPage() {
  return <Preview fileName="cache/02-data-cache-time-based/page.tsx" />;
}
