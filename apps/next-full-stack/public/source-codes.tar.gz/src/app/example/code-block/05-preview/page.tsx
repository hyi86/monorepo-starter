import { Preview } from './preview';

export default function CodeBlockPreviewPage() {
  return <Preview fileName="code-block/05-preview/preview-provider.tsx" />;
}
